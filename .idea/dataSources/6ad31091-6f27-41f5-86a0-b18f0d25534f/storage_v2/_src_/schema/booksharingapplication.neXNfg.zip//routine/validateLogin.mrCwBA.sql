CREATE PROCEDURE validateLogin(IN inptemail VARCHAR(50), IN inptpass VARCHAR(30), OUT validate INT)
  BEGIN
      
      SELECT count(*) INTO validate
      FROM user u
      WHERE u.email = inptemail
      AND
      u.password = inptpass;
      
END;

